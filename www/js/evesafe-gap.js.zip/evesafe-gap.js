/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

//declare here
var h = new Object();
var prev_event = false;

function app_initialize(app_input) {
    document.addEventListener('deviceready', onDeviceReady, false);
    
    // Cordova is ready to be used!
    //
    function onDeviceReady() {
        console.log('Javascript OK');
        switch(app_input){
            case 'geoLocation':
                initiate_geolocation();
                break;
            case 'fetchIce':
                fetch_Ice();
                break;
        }
    }
}

function initiate_geolocation() {
    navigator.geolocation.getCurrentPosition(handle_geolocation_query,handle_errors);
}

function handle_errors(error) {
    switch(error.code)
    {
        case error.PERMISSION_DENIED: alert("user did not share geolocation data");
            break;
        case error.POSITION_UNAVAILABLE: fallbackHtml5Location();
            break;
        case error.TIMEOUT: alert("retrieving position timed out");
            break;
        default: alert("unknown error");
            prev_event = true;
            break;
    }
}

function fallbackHtml5Location() {
    $.getJSON("http://freegeoip.net/json/", function(res){
              console.log('flow : inside falbackhtml5location');
              $('div.geoLocation').find('h2').append(res.longitude);
              $('div.geoLocation').find('h3').append(res.latitude);
              });
    prev_event = true;
}

function handle_geolocation_query(position){
    h['latitude']   = position.coords.latitude;
    h['longitude']  = position.coords.latitude;
    h['altitude']   = position.coords.altitude;
    h['accuracy']   = position.coords.accuracy;
    h['altitudeAccuracy'] = position.coords.altitudeAccuracy;
    h['heading']    = position.coords.heading;
    h['speed']      = position.coords.speed;
    h['timestamp']  = position.timestamp;
    console.log('while fetching ' + h['longitude']);
    $('div.geoLocation').find('h2').append('GPS: ' + position.coords.longitude);
    console.log('GPS: ' + position.coords.longitude);
    $('div.geoLocation').find('h3').append('GPS: ' + position.coords.latitude);
    var d = new Date(h['timestamp']);
    $('div.geoLocation').append(d.toLocaleString());
    prev_event = true;
    //Need to send SMS, and sync to JSON DB
}

function fetch_Ice() {
    console.log('current output ' + h['latitude'] );
    prev_event = true;
}

function checkPrevEvent() {
    (prev_event == false) ? console.log('flow - am waiting for previous event to finish')/*manually making synchronous sequence*/ : prev_event = false;
}

$(document).ready(function() {
    //toggle button css
    $('.old').mouseup(function () {
                      $(this).toggleClass('pushdown');
    });
                  
    app_initialize('geoLocation');//initializing deviceready for geoLocation
    setTimeout(function() {checkPrevEvent()}, 10000);
    app_initialize('fetchIce');//initializing deviceready for fetchIce
    setTimeout(function() {checkPrevEvent()}, 10000);



});